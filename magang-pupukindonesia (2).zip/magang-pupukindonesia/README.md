# skripsi
