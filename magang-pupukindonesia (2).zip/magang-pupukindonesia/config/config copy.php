<?php
/*
	mysql_connect("localhost",'root','') or die("Server off");
	mysql_select_db("data") or die("database not found");
	$koneksi=mysqli_connect("localhost","root","");
$selectdb= mysqli_select_db('penggajian') or die (' maaf database tidak ditemukan');
	*/
$server = 'sql205.epizy.com';
$username = 'epiz_30658647';
$dbpass = 'McPoqKkChYeM0z';
$dbname = 'epiz_30658647_data';

$conn = mysqli_connect($server, $username, $password, $dbname);

if(!$conn){
	die("connection failed:".mysqli_connect_error());
}
?>