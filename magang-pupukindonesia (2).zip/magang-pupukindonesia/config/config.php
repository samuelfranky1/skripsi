<?php
/*
	mysql_connect("localhost",'root','') or die("Server off");
	mysql_select_db("data") or die("database not found");
	$koneksi=mysqli_connect("localhost","root","");
$selectdb= mysqli_select_db('penggajian') or die (' maaf database tidak ditemukan');
	*/
$server = 'localhost';
$username = 'root';
$dbpass = '';
$dbname = 'webdb';
$conn = mysqli_connect($server, $username, $dbpass, $dbname);

if(!$conn){
	die("connection failed:".mysqli_connect_error());
}
?>