<?php
$con=mysqli_connect("sql205.epizy.com","epiz_30658647","McPoqKkChYeM0z","epiz_30658647_data") or die(mysqli_error($con));
//$con=mysqli_connect("localhost","root","","data") or die(mysqli_error($con));
?>
