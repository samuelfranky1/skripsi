<?php
$koneksi = mysqli_connect("localhost","id20205939_root","o*L#iK7wsy7-Y@Um","id20205939_webdb");
// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}

?>
