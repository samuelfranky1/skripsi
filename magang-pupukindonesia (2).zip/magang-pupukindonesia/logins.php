
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title>Login Page - SOA Admin</title>

		<meta name="description" content="User login page" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <link rel="stylesheet" href="style.css"  />


    <style type="text/css">
      .fil0 {fill:#C27B55}
    .fil1 {fill:#F2CBB6}
    .fil2 {fill:#FFF0E8}
    .author_info{
      text-align: center;
    }
    .author_info ul{
      list-style: none;
      margin-top: 10px;
    }
    .author_info ul li{
      margin-right: 10px;
      display: inline;
    }
    .author_info ul li a img{
      width: 40px;
    }
    </style>

		<!-- bootstrap & fontawesome -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
		<link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css" />

		<!-- text fonts -->
		<link rel="stylesheet" href="assets/css/fonts.googleapis.com.css" />

		<!-- ace styles -->
		<link rel="stylesheet" href="assets/css/ace.min.css" />

		<!--[if lte IE 9]>
			<link rel="stylesheet" href="assets/css/ace-part2.min.css" />
		<![endif]-->
		<link rel="stylesheet" href="assets/css/ace-rtl.min.css" />

		<!--[if lte IE 9]>
		  <link rel="stylesheet" href="assets/css/ace-ie.min.css" />
		<![endif]-->

		<!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

		<!--[if lte IE 8]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
		<![endif]-->
	</head>

	<body>
<form action="cek_login.php" method="post">
    <!-- <form > -->
	<div class="img">
		<div>



		</div>
	</div>

	<div class="inputGroup inputGroup1">
		<label for="loginEmail" id="loginEmailLabel">NIK</label>
		<input type="text" id="loginEmail" maxlength="8" name="nik" />

	</div>
	<div class="inputGroup inputGroup2">
		<label for="loginPassword" id="loginPasswordLabel">Password</label>
		<input type="password" id="loginPassword" name="password" />

	</div>
	<div class="inputGroup inputGroup3">
    <input type="submit" class="width-35 pull-right btn btn-sm btn-primary" value="LOGIN">
    </input>
	</div>
	<div>
</form>






<script src='https://cdnjs.cloudflare.com/ajax/libs/gsap/1.20.3/TweenMax.min.js'></script>
<script src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/16327/MorphSVGPlugin.min.js?r=182'></script>

<script>
var emailLabel = document.querySelector('#loginEmailLabel'),
    email = document.querySelector('#loginEmail'),
    passwordLabel = document.querySelector('#loginPasswordLabel'),
    password = document.querySelector('#loginPassword'),
        mySVG = document.querySelector('.svgContainer'),
    bodyBGchanged = document.querySelector('.bodyBGchanged');
	</script>



	<!-- lupa akun? -->

							<div class="navbar-fixed-back align-left">
						
								<br />
								&nbsp;
								<b><a id="btn-login" href="#">Kembali ke Menu utama</a></b>
								&nbsp;
								<span class="blue">/</span>
								&nbsp;
								<a id="btn-login-blur" href="#">Blur</a>
								&nbsp;
							</div>
						</div>
					</div><!-- /.col -->
				</div><!-- /.row -->
			</div><!-- /.main-content -->
		</div><!-- /.main-container -->

		<!-- basic scripts -->

		<!--[if !IE]> -->
		<script src="assets/js/jquery-2.1.4.min.js"></script>

		<!-- <![endif]-->

		<!--[if IE]>
<script src="assets/js/jquery-1.11.3.min.js"></script>
<![endif]-->
		<script type="text/javascript">
			if('ontouchstart' in document.documentElement) document.write("<script src='assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
		</script>

		<!-- inline scripts related to this page -->
		<script type="text/javascript">
			jQuery(function($) {
			 $(document).on('click', '.toolbar a[data-target]', function(e) {
				e.preventDefault();
				var target = $(this).data('target');
				$('.widget-box.visible').removeClass('visible');//hide others
				$(target).addClass('visible');//show target
			 });
			});



			//you don't need this, just used for changing background
			jQuery(function($) {
			 $('#btn-login-dark').on('click', function(e) {
				$('body').attr('class', 'login-layout');
				$('#id-text2').attr('class', 'white');
				$('#id-company-text').attr('class', 'blue');

				e.preventDefault();
			 });
			 $('#btn-login-light').on('click', function(e) {
				$('body').attr('class', 'login-layout light-login');
				$('#id-text2').attr('class', 'grey');
				$('#id-company-text').attr('class', 'blue');

				e.preventDefault();
			 });
			 $('#btn-login-blur').on('click', function(e) {
				$('body').attr('class', 'login-layout blur-login');
				$('#id-text2').attr('class', 'white');
				$('#id-company-text').attr('class', 'light-blue');

				e.preventDefault();
			 });

			});
		</script>

	</body>
</html>
