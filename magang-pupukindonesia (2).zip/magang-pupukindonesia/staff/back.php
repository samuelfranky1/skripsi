<?php
// mengaktifkan session php
session_start();

// mengalihkan halaman ke halaman login
header("location:../home.php");
?>
