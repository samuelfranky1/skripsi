<?php
    session_start();
    session_unset();
    session_destroy();
?>
<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />

    <title>Taktemu.id - Elearning Design</title>
    <meta content="" name="description" />
    <meta content="" name="keywords" />


<html>
    <head>

<!-- <div class="iframe-embed" style="left: 0; width: 100%; height: 0; position: relative; padding-bottom: 75%;"><iframe src="https://dribbble.com/shots/15379368-Quick-Animation-Experiment/player" style="border: 0; top: 0; left: 0; width: 100%; height: 100%; position: absolute;" allowfullscreen allow="encrypted-media"></iframe></div> -->

  <div id="app">
  <div class="title">
    <div class="title-inner">
      <div class="cafe">
        <div class="cafe-inner">Telah Keluar</div>
      </div>
      <div class="mozart">
        <a class="mozart-inner">Login Lagi ya?</a>
      
      </div>
    </div>
  </div>

  <div class="image">
    <img src='https://upload.wikimedia.org/wikipedia/commons/d/da/Logo_Pupuk_Indonesia_%28Persero%29.png' alt=''>
  </div>

<script src="https://codepen.io/shshaw/pen/QmZYMG.js"></script>
    <body>
    <div class="counts container">

                      

  
                             
  </div>
</div>
